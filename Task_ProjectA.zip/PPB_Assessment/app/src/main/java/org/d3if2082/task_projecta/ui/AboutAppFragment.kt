package org.d3if2082.task_projecta.ui

import androidx.fragment.app.Fragment
import org.d3if2082.task_projecta.R

class AboutAppFragment : Fragment(R.layout.fragment_aboutapp) {
}