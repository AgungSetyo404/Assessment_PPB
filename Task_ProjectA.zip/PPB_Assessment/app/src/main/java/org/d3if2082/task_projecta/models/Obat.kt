package org.d3if2082.task_projecta.models

data class Obat(
    val namaObat: String,
    val imageid: Int,
    val keterangan: String
)

