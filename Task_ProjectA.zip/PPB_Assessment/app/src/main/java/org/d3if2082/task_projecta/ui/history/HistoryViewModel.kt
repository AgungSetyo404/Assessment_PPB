package org.d3if2082.task_projecta.ui.history

class HistoryViewModel {
}